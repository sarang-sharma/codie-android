package org.codiecon.reportit.adapters;

import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import org.codiecon.reportit.R;
import org.codiecon.reportit.models.ReportedIssue;

import java.util.List;

public class ReportedIssueAdapter extends RecyclerView.Adapter<ReportedIssueAdapter.IssueHolder> {

    private List<ReportedIssue> issues;

    public ReportedIssueAdapter(List<ReportedIssue> reportedIssues) {
        this.issues = reportedIssues;
    }

    @NonNull
    @Override
    public ReportedIssueAdapter.IssueHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
            .inflate(R.layout.issue_card, parent, false);

        return new IssueHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ReportedIssueAdapter.IssueHolder holder, int position) {
        ReportedIssue issue = this.issues.get(position);
        holder.textView.setText(issue.getTitle());
    }

    @Override
    public int getItemCount() {
        return issues.size();
    }

    public class IssueHolder extends RecyclerView.ViewHolder {

        TextView textView;

        ImageView imageView;

        public IssueHolder(View view) {
            super(view);
            textView = view.findViewById(R.id.card_title);
            imageView = view.findViewById(R.id.card_image);
        }
    }
}
