package org.codiecon.reportit.models;

public class UserPrincipal {

    private String identifier;

    private String name;

    public String getIdentifier() {
        return identifier;
    }

    public String getName() {
        return name;
    }
}
